<?php

return array(
    'APP_SUB_DOMAIN_DEPLOY' => 1,
    'APP_SUB_DOMAIN_RULES' => array(
        'admin2.ydtest.xyz' => array('Manage/'),
        
        'm2.ydtest.xyz' => array('Wchat/'),
    ),
);