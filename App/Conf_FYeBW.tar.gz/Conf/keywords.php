<?php
return array(
    'backend_admin_index'=>'backend_admin_index_moneyview',
    'login_admin'=>'backend_admin_index_moneyview',
    'default_loan_setting'=>'default_loan_setting_moneyview',
    'key_import_user_list'=>'key_import_user_list_moneyview',
);